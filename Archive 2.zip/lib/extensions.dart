/// Extensions implementing various additional methods on Dart or Flutter
/// base classes.
///
/// To use, import `package:diary/extensions.dart`.
library extensions;

part 'extensions/string_extension.dart';
