part of widgets;

abstract class BookmarkDesign extends Widget {}

enum DesignType {
  stiped,
  dotted,
}
