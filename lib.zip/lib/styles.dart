/// A collection of styling components and elements applied on History of me.
///
/// To use, import `package:diary/styles.dart`

library styles;

import 'package:flutter/material.dart';

part 'styles/app_colors.dart';
