part of static;

/// A `History of Me` `static` class containg paths to the app's assets.
class AppAssets {
  static const String _root = "assets/images/";

  /// The `History of Me` key logo.
  static const keyLogo = _root + "icons8-diary-64.png";
}
